import SwiftUI

struct RootView: View {
    @Bindable var session: DemoSession
    @State private var menuIsOpen = false
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @AccessibilityFocusState private var menuFocus: Bool
    @AccessibilityFocusState private var headerFocus: Bool

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                VStack(spacing: 0) {
                    ScreenHeader(
                        title: session.section == .capture ? "MemoryOS" : session.section.title(in: session.language),
                        menuLabel: session.language.text("Open menu", "فتح القائمة"),
                        openMenu: { setMenu(true) }
                    )
                    .accessibilityFocused($headerFocus)

                    if session.section == .capture {
                        CaptureView(session: session, menuIsOpen: menuIsOpen)
                    } else {
                        SectionView(session: session)
                    }
                }
                .accessibilityHidden(menuIsOpen)
                .allowsHitTesting(!menuIsOpen)

                Color.black.opacity(menuIsOpen ? 0.6 : 0)
                    .ignoresSafeArea(edges: .bottom)
                    .contentShape(Rectangle())
                    .onTapGesture { setMenu(false) }
                    .allowsHitTesting(menuIsOpen)
                    .accessibilityHidden(true)

                SidebarView(session: session, close: { setMenu(false) })
                    .frame(width: geometry.size.width * 0.84)
                    .frame(maxHeight: .infinity)
                    .background(MemoryTheme.panel)
                    // SwiftUI mirrors the horizontal offset in RTL.
                    .offset(x: menuIsOpen ? 0 : -geometry.size.width * 0.84)
                    .allowsHitTesting(menuIsOpen)
                    .accessibilityHidden(!menuIsOpen)
                    .accessibilityFocused($menuFocus)
                    .accessibilityAddTraits(.isModal)
                    .accessibilityAction(.escape) { setMenu(false) }
            }
            .background(MemoryTheme.canvas)
            .foregroundStyle(MemoryTheme.ink)
        }
    }

    private func setMenu(_ open: Bool) {
        withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) {
            menuIsOpen = open
        }
        menuFocus = open
        headerFocus = !open
    }
}
