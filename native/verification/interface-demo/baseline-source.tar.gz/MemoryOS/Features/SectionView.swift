import SwiftUI

struct SectionView: View {
    @Bindable var session: DemoSession
    private var language: AppLanguage { session.language }

    var body: some View {
        Group {
            switch session.section {
            case .settings:
                Form {
                    Picker(language.text("Language", "اللغة"), selection: $session.language) {
                        ForEach(AppLanguage.allCases) { item in
                            Text(item.name).tag(item)
                        }
                    }
                    .accessibilityIdentifier("language-picker")
                    Text(language.text("Interface demo. Memories last for this session only.", "عرض للواجهة. تبقى الذكريات لهذه الجلسة فقط."))
                        .foregroundStyle(MemoryTheme.secondary)
                }
                .scrollContentBackground(.hidden)
            case .memories:
                if session.memories.isEmpty {
                    ContentUnavailableView(language.text("Your memories", "ذكرياتك"), systemImage: "doc.text", description: Text(language.text("Thoughts you add in this demo appear here until the app closes.", "تظهر هنا الأفكار التي تضيفها في هذا العرض حتى إغلاق التطبيق.")))
                } else {
                    List {
                        Section {
                            ForEach(session.memories) { memory in
                                Text(memory.text).textSelection(.enabled)
                            }
                        } footer: {
                            Text(language.text("Demo memories. Cleared when the app closes.", "ذكريات تجريبية. تُمسح عند إغلاق التطبيق."))
                        }
                    }
                    .listStyle(.plain)
                }
            default:
                ContentUnavailableView(session.section.title(in: language), systemImage: session.section.symbol, description: Text(language.text("This section is ready for the next design step.", "هذا القسم جاهز لخطوة التصميم التالية.")))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
